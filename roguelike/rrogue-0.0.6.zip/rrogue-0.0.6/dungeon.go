package main

//Dungeon is a container for all the levels that make up a particular dungeon in the world.
type Dungeon struct {
	Name   string
	Levels []Level
}
